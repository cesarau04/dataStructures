The complexity of the Evaluation class using the recursive method is O(n)
	This becuse the intructions are O(1) or O(n) or O(x) and in the sum the result is O(n)

The complexity of the Iterative method is the same O(n)
	This because is based on the Iterative method of the other class.